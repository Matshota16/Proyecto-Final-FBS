<?php

// Generación de registros
for ($i = 1; $i <= 600; $i++) { // Suponiendo que quieres insertar 600 registros
    $idPeticionViaje = $i; // ID de la petición de viaje igual al contador de bucle
    $idConductor = rand(1, 50); // Suponiendo que tienes 100 conductores y los IDs van desde 1 hasta 100
    $distanciaRecorrida = rand(1, 15); // Distancia recorrida aleatoria entre 1 y 100 kilómetros
    
    // Generar la consulta SQL
    $sql = "INSERT INTO viaje (idviaje, idpeticiondeviaje, idconductor, distanciarecorrida, create_at, update_at) 
            VALUES ($i, $idPeticionViaje, $idConductor, $distanciaRecorrida, NOW(), NOW());";
    
    echo $sql . "<br>";
}

?>