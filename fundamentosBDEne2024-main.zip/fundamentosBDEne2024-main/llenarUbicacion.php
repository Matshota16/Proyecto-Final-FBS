<?php

// Arreglos de datos para generar ubicaciones aleatorias
$calles = ["Calle Independencia", "Avenida Juárez", "Calle Reforma", "Boulevard Hidalgo", "Avenida Morelos", "Calle Miguel Hidalgo", "Avenida Constitución", "Calle Zaragoza", "Calle Benito Juárez", "Avenida Revolución"];
$ciudades = ["Teziutlan", "chignautla", "chignaulingo", "acateno"];
$municipios = ["Teziutlan", "chignautla", "chignaulingo", "acateno"];
$estados = ["Puebla"];
$codigosPostales = ["73800", "73820", "73810", "73830"];

// Generación de registros
for ($i = 1; $i <= 50; $i++) { // Suponiendo que quieres insertar 50 registros
    $codigoPostal = obtenerAleatorio($codigosPostales);
    $calle = obtenerAleatorio($calles);
    $ciudad = obtenerAleatorio($ciudades);
    $municipio = obtenerAleatorio($municipios);
    $estado = obtenerAleatorio($estados);
    
    // Generar la consulta SQL
    $sql = "INSERT INTO ubicacion (idubicacion, codigopostal, calle, ciudad, municipio, estado, create_at, update_at) 
            VALUES ($i, $codigoPostal, '$calle', '$ciudad', '$municipio', '$estado', NOW(), NOW());";
    
    echo $sql . "<br>";
}

// Función para obtener un elemento aleatorio de un arreglo
function obtenerAleatorio($arreglo) {
    $indice = array_rand($arreglo);
    return $arreglo[$indice];
}

?>