<?php

for ($i = 1; $i <= 50; $i++) { 

    $sql = "INSERT INTO conductorvehiculo (id, idvehiculo, idconductor, create_at, update_at) 
            VALUES ($i, $i, $i, NOW(), NOW());";
    
    echo $sql . "<br>";
}

?>