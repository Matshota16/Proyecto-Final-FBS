<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="<?=base_url('code/highcharts.js'); ?>">
  <style type="text/css">
    #container {
      height: 400px;
    }
  </style>
</head>

<body style="background: url('fondo.png') no-repeat; background-size: cover;">
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <img src="<?=base_url('uber.png'); ?>" style="transform: scale(1);">
      <a class="navbar-brand" href="<?=base_url('introduccion.php');?>"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('/Clientes/show')?>">Clientes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('/Viajes/show')?>">Viajes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('/Conductores/show')?>">Conductores</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('/Vehiculos/show')?>">Vehiculos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('/Viajes/show1')?>">Viajes por Conductor</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('/Peticion/show')?>">Lugares con mas viajes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('/Viajes/show2')?>">Promedio de personas por viaje</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('/Viajes/show3')?>">Datos estadisticos personas</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('/Viajes/show5')?>">Datos estadisticos edad</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('/Viajes/show4')?>">Ganancias</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>
</body>
</html>