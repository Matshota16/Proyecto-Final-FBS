<h1>Hola</h1>

<ul>


<?php  foreach ($analisis as $key) : ?>
    <li><?=$key->nombre ?></li>
<?php endforeach ?>
</ul>