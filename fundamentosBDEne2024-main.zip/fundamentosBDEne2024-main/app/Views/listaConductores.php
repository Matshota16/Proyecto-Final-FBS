<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            width: 60%;
            margin: 0 auto;
            padding: 20px;
        }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
<div class="container">
    <table class="table table-secondary">
        <thead>
            <th>id</th>
            <th>Nombre</th>
            <th>Apellido Paterno</th>
            <th>Apellido Materno</th>
            <th>Genero</th>
            <th>Edad</th>
        </thead>
        <tbody>
            <?php foreach ($Conductores as $conductor) :?>
                <tr>
                    <td><?= $conductor->idconductor ?></td>
                    <td><?= $conductor->nombre ?></td>
                    <td><?= $conductor->apellidopaterno ?></td>
                    <td><?= $conductor->apellidomaterno ?></td>
                    <td><?= $conductor->genero ?></td>
                    <td><?= $conductor->edad ?></td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<script src="js/bootstrap.js"></script>
</body>
</html>
