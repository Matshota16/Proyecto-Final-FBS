<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Viaje</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            width: 60%;
            margin: 0 auto;
            padding: 20px;
        }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
<div class="container">
    <table class="table table-secondary">
        <thead>
            <tr>
                <th>Nombre del Cliente</th>
                <th>Nombre del Conductor</th>
                <th>Distancia Recorrida</th>
                <th>Cantidad de Personas</th>
                <th>Costo Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalleViaje as $detalle): ?>
                <tr>
                    <td><?= $detalle->nombre_cliente ?></td>
                    <td><?= $detalle->nombre_conductor ?></td>
                    <td><?= $detalle->distanciarecorrida ?></td>
                    <td><?= $detalle->cantidaddepersonas ?></td>
                    <td><?= $detalle->costo_total ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script src="js/bootstrap.js"></script>
</body>
</html>

