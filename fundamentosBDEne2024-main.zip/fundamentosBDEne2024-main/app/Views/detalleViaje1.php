<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Viaje</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            #container {
      height: 400px;
    }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
<script src=<?=base_url('code/highcharts.js'); ?>></script>
<script src=<?=base_url('code/modules/data.js'); ?>></script>
<script src=<?=base_url('code/modules/exporting.js'); ?>></script>
<script src=<?=base_url('code/modules/export-data.js'); ?>></script>
<script src=<?=base_url('code/modules/accessibility.js'); ?>></script>

<div class="container">
    <div class="row">
        <div class="col-12">
            <figure class="highcharts-figure">
                <div id="container"></div>
                <p class="highcharts-description">
                    Cantidad de viajes que an realizado los diferentes conductores

            </figure>
    <table class="table table-secondary" id="datatable">
        <thead>
            <tr>
                <th>Nombre del Conductor</th>
                <th>Cantidad de Viajes</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalleViaje1 as $detalle1): ?>
                <tr>
                    <td><?= $detalle1->nombre_conductor ?></td>
                    <td><?= $detalle1->cantidad ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script type="text/javascript">
                Highcharts.chart('container', {
                    data: {
                        // Aqui es donde van los datos correspondientes que formaran la grafica, y se agarran de la tabla
                        table: 'datatable'
                    },
                    chart: {
                        type: 'column'
                    },
                    title: {
                        // Aquí se genera un pequeño titulo donde se mostrara informacion sobre de que es la grafica
                        text: 'Numeros de viajes que an hecho los conductores'
                    },
                    xAxis: {
                        // Aquí se define la configuración del eje X de la gráfica
                        type: 'category'
                    },
                    yAxis: {
                        // Aquí se define la configuración del eje Y de la gráfica
                        allowDecimals: false,
                        title: {
                            text: 'Cantidad de viajes'
                        }
                    }
                });
            </script>
</body>
</html>