
<ul>


<?php  foreach ($analisis as $key) : ?>
    <li><?=$key->nombre ?> , <?=$key->precio ?></li>
<?php endforeach ?>
</ul>