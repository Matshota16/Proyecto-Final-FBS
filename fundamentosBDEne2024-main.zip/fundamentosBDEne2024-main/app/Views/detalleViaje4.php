<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Viaje</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            #container {
      height: 400px;
    }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
    
<script src=<?=base_url('code/highcharts.js'); ?>></script>
<script src=<?=base_url('code/modules/series-label.js'); ?>></script>
<script src=<?=base_url('code/modules/exporting.js'); ?>></script>
<script src=<?=base_url('code/modules/export-data.js'); ?>></script>
<script src=<?=base_url('code/modules/accessibility.js'); ?>></script>
<div class="container">
    <div class="row">
        <div class="col-12">
            <figure class="highcharts-figure">
                <div id="container"></div>
                <p class="parrafo">Tomando datos de el formulario y los registros de la edad, se scaraon estas medidas
                    de dispercion y de tendencia central

                </p>
            </figure>
            <table class="table table-secondary" id="datatable">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Ganancias Por dia</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalleViaje4 as $detalle4): ?>
                <tr>
                    <td><?= $detalle4->fecha ?></td>
                    <td><?= $detalle4->ganancias_totales ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script type="text/javascript">
Highcharts.chart('container', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Ganancias generadas por dia',
        align: 'left'
    },
    xAxis: {
        categories: [<?php foreach ($detalleViaje4 as $detalle4): ?>
                    '<?= $detalle4->fecha ?>',
                <?php endforeach; ?>]
    },
    yAxis: {
        title: {
            text: 'Ganancias'
        }
    },
    credits: {
        enabled: false
    },
    series: [{
        name: 'Ganancias totales',
        data: [<?php foreach ($detalleViaje4 as $detalle4): ?>
                    <?= $detalle4->ganancias_totales ?>,
                <?php endforeach; ?>
        ]
    }]
});
</script>
</body>
</html>