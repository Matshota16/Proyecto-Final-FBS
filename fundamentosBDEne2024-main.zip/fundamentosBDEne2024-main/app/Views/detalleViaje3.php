<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Viaje</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            #container {
      height: 400px;
    }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
    
<script src=<?=base_url('code/highcharts.js'); ?>></script>
<script src=<?=base_url('code/modules/series-label.js'); ?>></script>
<script src=<?=base_url('code/modules/exporting.js'); ?>></script>
<script src=<?=base_url('code/modules/export-data.js'); ?>></script>
<script src=<?=base_url('code/modules/accessibility.js'); ?>></script>
<div class="container">
    <div class="row">
        <div class="col-12">
            <figure class="highcharts-figure">
                <div id="container"></div>
                <p class="parrafo">Tomando datos de el formulario y los registros de la edad, se scaraon estas medidas
                    de dispercion y de tendencia central

                </p>
            </figure>
            <table class="table table-secondary" id="datatable">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Media</th>
                <th>Desviacion estandar</th>
                <th>Moda</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalleViaje3 as $detalle3): ?>
                <tr>
                    <td><?= $detalle3->fecha ?></td>
                    <td><?= $detalle3->media_cantidad_personas ?></td>
                    <td><?= $detalle3->desviacion_estandar_cantidad_personas ?></td>
                    <td><?= $detalle3->moda_cantidad_personas ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script type="text/javascript">
    Highcharts.chart('container', {
        title: {
            text: 'Datos de tendencia central y de dispersión cantidad de personas',
            align: 'left'
        },
        yAxis: {
            title: {
                text: 'Cantidad'
            }
        },
        xAxis: {
            categories: [
                <?php foreach ($detalleViaje3 as $detalle3): ?>
                    '<?= $detalle3->fecha ?>',
                <?php endforeach; ?>
            ]
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle'
        },
        plotOptions: {
            series: {
                label: {
                    connectorAllowed: false
                }
            }
        },
        series: [{
            name: 'Media Cantidad de Personas',
            data: [
                <?php foreach ($detalleViaje3 as $detalle3): ?>
                    <?= $detalle3->media_cantidad_personas ?>,
                <?php endforeach; ?>
            ]
        }, {
            name: 'Desviación Estándar Cantidad de Personas',
            data: [
                <?php foreach ($detalleViaje3 as $detalle3): ?>
                    <?= $detalle3->desviacion_estandar_cantidad_personas ?>,
                <?php endforeach; ?>
            ]
        }, {
            name: 'Moda Cantidad de Personas',
            data: [
                <?php foreach ($detalleViaje3 as $detalle3): ?>
                    <?= $detalle3->moda_cantidad_personas ?>,
                <?php endforeach; ?>
            ]
        }],
        responsive: {
            rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    legend: {
                        layout: 'horizontal',
                        align: 'center',
                        verticalAlign: 'bottom'
                    }
                }
            }]
        }
    });
</script>
</body>
</html>