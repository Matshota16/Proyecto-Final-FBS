<?php 


print_r($producto);

?>

<h1><?=$producto[0]->NombreProducto ?> </h1>
<p><?=$producto[0]->Descripcion ?></p>