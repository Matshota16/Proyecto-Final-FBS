<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Viaje</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            #container {
      height: 400px;
    }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
<script src=<?=base_url('code/highcharts.js'); ?>></script>
<script src=<?=base_url('code/modules/data.js'); ?>></script>
<script src=<?=base_url('code/modules/exporting.js'); ?>></script>
<script src=<?=base_url('code/modules/export-data.js'); ?>></script>
<script src=<?=base_url('code/modules/accessibility.js'); ?>></script>

<div class="container">
    <div class="row">
        <div class="col-12">
            <figure class="highcharts-figure">
                <div id="container"></div>
                <p class="highcharts-description">
                    Zonas donde es mas frecuente el uso de la aplicacion

            </figure>
    <table class="table table-secondary" id="datatable">
        <thead>
            <tr>
                <th>Nombre del Conductor</th>
                <th>Cantidad de Viajes</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalleUbicacion as $detalle): ?>
                <tr>
                    <td><?= $detalle->municipio ?></td>
                    <td><?= $detalle->cantidad_peticiones ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script type="text/javascript">
        Highcharts.chart('container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Porcentaje de viajes',
                align: 'left'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            accessibility: {
                point: {
                    valueSuffix: '%'
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                        name: 'Porcentaje',
                        colorByPoint: true,
                        data: [
                            <?php foreach ($detalleUbicacion as $detalle): ?>
                                {
                                    name: '<?= $detalle->municipio ?>',
                                    y: <?= $detalle->cantidad_peticiones ?>
                                },
                            <?php endforeach; ?>
                        ]
                    }]
                });
            </script>
        </div>
    </div>
</div>
</body>
</html>