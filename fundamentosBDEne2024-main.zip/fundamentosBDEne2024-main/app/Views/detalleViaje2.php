<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Viaje</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            #container {
      height: 400px;
    }
        .table {
            margin: 0 auto;
        }
    </style>
</head>
<body>
<script src=<?=base_url('code/highcharts.js'); ?>></script>
<script src=<?=base_url('code/modules/data.js'); ?>></script>
<script src=<?=base_url('code/modules/exporting.js'); ?>></script>
<script src=<?=base_url('code/modules/export-data.js'); ?>></script>
<script src=<?=base_url('code/modules/accessibility.js'); ?>></script>

<div class="container">
    <div class="row">
        <div class="col-12">
            <figure class="highcharts-figure">
                <div id="container"></div>
                <p class="highcharts-description">
                    Porcentaje de la cantidad de personas por viajes

            </figure>
    <table class="table table-secondary" id="datatable">
        <thead>
            <tr>
                <th>Cantidad de personas en el viaje</th>
                <th>Cantidad de Viajes con esas personas</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalleViaje2 as $detalle2): ?>
                <tr>
                    <td><?= $detalle2->cantidaddepersonas ?></td>
                    <td><?= $detalle2->total_peticiones ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script type="text/javascript">
    Highcharts.setOptions({
        colors: Highcharts.map(Highcharts.getOptions().colors, function(color) {
            return {
                radialGradient: {
                    cx: 0.5,
                    cy: 0.3,
                    r: 0.7
                },
                stops: [
                    [0, color],
                    [1, Highcharts.color(color).brighten(-0.3).get('rgb')] // darken
                ]
            };
        })
    });
    Highcharts.chart('container', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            // Aquí se genera un pequeño titulo donde se mostrara informacion sobre de que es la grafica
            text: 'Cantidad de personas',
            align: 'left'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            // Aquí se definen las opciones de estilo y comportamiento de la gráfica
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<span style="font-size: 1.2em"><b>{point.name}</b></span><br>' +
                        '<span style="opacity: 0.6">{point.percentage:.1f} %</span>',
                    connectorColor: 'rgba(128,128,128,0.5)'
                }
            }
        },
        series: [{
            // Aquí se definen las series de datos que se mostrarán en la gráfica
            name: 'porcentaje',
            data: [
                <?php foreach ($detalleViaje2 as $detalle2): ?> {
                        name: <?php echo $detalle2->cantidaddepersonas ?>,
                        y: <?php echo $detalle2->total_peticiones ?>
                    },
                    <?php endforeach; ?>
            ]
        }]
    });
    
</script>
</body>
</html>