<?php

namespace App\Models;

use CodeIgniter\Model;

class ViajeModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'viaje';
    protected $primaryKey       = 'idviaje';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function getDetalle(){
        $db = db_connect();
        $query = $db->table('viaje')
                    ->select('CONCAT(cliente.nombre, " ", cliente.apellidopaterno, " ", cliente.apellidomaterno) AS nombre_cliente')
                    ->select('CONCAT(conductor.nombre, " ", conductor.apellidopaterno, " ", conductor.apellidomaterno) AS nombre_conductor')
                    ->select('viaje.distanciarecorrida')
                    ->select('peticiondeviaje.cantidaddepersonas')
                    ->select('(viaje.distanciarecorrida * 12 * peticiondeviaje.cantidaddepersonas) AS costo_total')
                    ->join('peticiondeviaje', 'viaje.idpeticiondeviaje = peticiondeviaje.idpeticion')
                    ->join('cliente', 'peticiondeviaje.idcliente = cliente.idcliente')
                    ->join('conductor', 'viaje.idconductor = conductor.idconductor')
                    ->get();

        return $query->getResult();
    }
    public function getDetalle1(){
        $db1 = db_connect();
        $query1 = $db1->table('viaje')
                    ->select('CONCAT(conductor.nombre, " ", conductor.apellidopaterno, " ", conductor.apellidomaterno) AS nombre_conductor')
                    ->select('COUNT(viaje.idviaje) AS cantidad')
                    ->join('conductor', 'viaje.idconductor = conductor.idconductor')
                    ->groupBy('conductor.nombre, conductor.apellidopaterno, conductor.apellidomaterno')
                    ->get();
    
        return $query1->getResult();
    }
    public function getDetalle2(){
        $db2 = db_connect();
        $query2 = $db2->table('peticiondeviaje')
        ->select('cantidaddepersonas, COUNT(*) AS total_peticiones')
        ->groupBy('cantidaddepersonas')
                    ->get();
    
        return $query2->getResult();
    }
    public function getDetalle3() {
        $db3 = db_connect();
        $query3 = $db3->query('
            SELECT 
                DATE(fechadeinicio) AS fecha,
                COUNT(*) AS cantidad_de_viajes,
                AVG(cantidaddepersonas) AS media_cantidad_personas,
                STDDEV_POP(cantidaddepersonas) AS desviacion_estandar_cantidad_personas,
                (SELECT cantidaddepersonas 
                 FROM peticiondeviaje 
                 WHERE DATE(fechadeinicio) = fecha 
                 GROUP BY cantidaddepersonas 
                 ORDER BY COUNT(*) DESC 
                 LIMIT 1) AS moda_cantidad_personas
            FROM peticiondeviaje
            GROUP BY DATE(fechadeinicio)
        ');
        return $query3->getResult();
    }
    public function getDetalle4() {
        $db4 = db_connect();
        $query4 = $db4->query('
        SELECT
        DATE(p.fechadeinicio) AS fecha,
        SUM(v.distanciarecorrida * 12 * p.cantidaddepersonas) AS ganancias_totales
        FROM viaje v
        JOIN peticiondeviaje p ON v.idpeticiondeviaje = p.idpeticion
        GROUP BY DATE(p.fechadeinicio);
        ');
        return $query4->getResult();
    }
    public function getDetalle5() {
        $db5 = db_connect();
        $query5 = $db5->query('
        SELECT 
        DATE(fechadeinicio) AS fecha,
        (SELECT edad 
         FROM cliente 
         WHERE DATE(fechadeinicio) = fecha 
         GROUP BY edad 
         ORDER BY COUNT(*) DESC 
         LIMIT 1) AS moda_edad,
        AVG(edad) AS media_edad,
        STDDEV_POP(edad) AS desviacion_estandar_edad
    FROM 
        peticiondeviaje
    JOIN 
        cliente ON peticiondeviaje.idcliente = cliente.idcliente
    GROUP BY 
        DATE(fechadeinicio);
        ');
        return $query5->getResult();
    }
}
?>