<?php

namespace App\Models;

use CodeIgniter\Model;

class PeticionDeViajeModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'peticiondeviaje';
    protected $primaryKey       = 'idpeticion';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function getDetalle(){
        $db = db_connect();
        $query = $db->query('SELECT 
                                subquery.municipio,
                                subquery.cantidad_peticiones
                            FROM (
                                SELECT u.municipio, COUNT(*) AS cantidad_peticiones
                                FROM peticiondeviaje pv
                                JOIN puntoinicial pi ON pv.idpuntoinicial = pi.idpuntoinicial
                                JOIN ubicacion u ON pi.idubicacion = u.idubicacion
                                GROUP BY u.municipio
                            ) AS subquery
                            ORDER BY subquery.cantidad_peticiones DESC;');
    
                    return $query->getResult();
    }
}
?>