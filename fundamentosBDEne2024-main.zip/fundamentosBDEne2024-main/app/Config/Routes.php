<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('/Clientes/detalle/(:num)', 'ClienteController::detalle/$1');

$routes->get('/Clientes/show', 'ClienteController::show');

$routes->get('/Vehiculos/show', 'VehiculoController::show');

$routes->get('/Viajes/show', 'ViajeController::mostrarDetalleViaje');
$routes->get('viaje/detalle/(:num)', 'ViajeController::mostrarDetalleViaje/$1');

$routes->get('/Peticion/show', 'PeticionDeViajeController::mostrarUbicaciones');
$routes->get('Peticion/detalle/(:num)', 'PeticionDeViajeController::mostrarUbicaciones/$1');

$routes->get('/Viajes/show1', 'ViajeController::mostrarDetalleViaje1');
$routes->get('viaje/detalle1/(:num)', 'ViajeController::mostrarDetalleViaje1');

$routes->get('/Viajes/show2', 'ViajeController::mostrarDetalleViaje2');
$routes->get('viaje/detalle2/(:num)', 'ViajeController::mostrarDetalleViaje2');

$routes->get('/Viajes/show3', 'ViajeController::mostrarDetalleViaje3');
$routes->get('viaje/detalle3/(:num)', 'ViajeController::mostrarDetalleViaje3');

$routes->get('/Viajes/show4', 'ViajeController::mostrarDetalleViaje4');
$routes->get('viaje/detalle4/(:num)', 'ViajeController::mostrarDetalleViaje4');

$routes->get('/Viajes/show5', 'ViajeController::mostrarDetalleViaje5');
$routes->get('viaje/detalle5/(:num)', 'ViajeController::mostrarDetalleViaje5');

$routes->get('/Conductores/show', 'ConductorController::show');
