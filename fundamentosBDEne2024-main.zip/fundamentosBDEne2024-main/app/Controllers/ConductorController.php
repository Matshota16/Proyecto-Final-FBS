<?php

namespace App\Controllers;

class ConductorController extends BaseController
{
    public function index()
    {
       
    }

    public function show(){
        $ConductorM = model('ConductorModel');
        $data['Conductores'] = $ConductorM->findAll();
        return  view('header').
                view('listaConductores',$data);
    }

    public function showCards(){
        $ConductorM = model('ConductorModel');
        $data['Conductores'] = $ConductorM->findAll();
        return  view('header').
                view('cardsConductores',$data);
    }

    public function detalle($idcliente){
       
        $ConductorM = model('ConductorModel');
        $data['Cliente'] = $ConductorM->getDetalle($idcliente);
        return  view('header').
                view('detalleCliente',$data);
    }
}