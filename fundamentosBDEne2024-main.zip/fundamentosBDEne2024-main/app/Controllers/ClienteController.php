<?php

namespace App\Controllers;

class ClienteController extends BaseController
{
    public function index()
    {
       
    }

    public function show(){
        $ClienteM = model('ClienteModel');
        $data['Clientes'] = $ClienteM->findAll();
        return  view('header').
                view('listaNombre',$data);
    }

    public function detalle($idcliente){
       
        $ClienteM = model('ClientesModel');
        $data['Cliente'] = $ClienteM->getDetalle($idcliente);
        return  view('header').
                view('detalleCliente',$data);
    }
}