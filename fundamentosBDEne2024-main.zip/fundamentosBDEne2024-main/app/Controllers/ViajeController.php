<?php

namespace App\Controllers;

class ViajeController extends BaseController
{
    public function mostrarDetalleViaje(){
        $viajeModel = model('ViajeModel');
        $data['detalleViaje'] = $viajeModel->getDetalle();
        return view('header') . 
               view('detalleViaje', $data); 
    }
    public function mostrarDetalleViaje1(){
        $viajeModel = model('ViajeModel');
        $data['detalleViaje1'] = $viajeModel->getDetalle1();
        return view('header') . 
               view('detalleViaje1', $data);
    }
    public function mostrarDetalleViaje2(){
        $viajeModel = model('ViajeModel');
        $data['detalleViaje2'] = $viajeModel->getDetalle2();
        return view('header') . 
               view('detalleViaje2', $data);
    }
    public function mostrarDetalleViaje3(){
        $viajeModel = model('ViajeModel');
        $data['detalleViaje3'] = $viajeModel->getDetalle3();
        return view('header') . 
               view('detalleViaje3', $data);
    }
    public function mostrarDetalleViaje4(){
        $viajeModel = model('ViajeModel');
        $data['detalleViaje4'] = $viajeModel->getDetalle4();
        return view('header') . 
               view('detalleViaje4', $data);
    }
    public function mostrarDetalleViaje5(){
        $viajeModel = model('ViajeModel');
        $data['detalleViaje5'] = $viajeModel->getDetalle5();
        return view('header') . 
               view('detalleViaje5', $data);
    }
}

?>