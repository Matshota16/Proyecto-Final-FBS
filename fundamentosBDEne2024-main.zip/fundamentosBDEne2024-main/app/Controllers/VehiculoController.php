<?php

namespace App\Controllers;

class VehiculoController extends BaseController
{
    public function index()
    {
       
    }

    public function show(){
        $VehiculoM = model('VehiculoModel');
        $data['Vehiculos'] = $VehiculoM->findAll();
        return  view('header').
                view('listaVehiculos',$data);
    }
}