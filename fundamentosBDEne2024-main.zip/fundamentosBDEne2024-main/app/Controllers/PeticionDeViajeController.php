<?php

namespace App\Controllers;

class PeticionDeViajeController extends BaseController
{
    public function index()
    {
       
    }
    public function mostrarUbicaciones(){
        $PeticionDeViajeM = model('PeticionDeViajeModel');
        $data['detalleUbicacion'] = $PeticionDeViajeM->getDetalle();
        return view('header') . 
               view('detalleUbicacion', $data); 
    }
}