<?php

// Generación de registros
for ($i = 1; $i <= 300; $i++) { // Suponiendo que quieres insertar 50 registros
    $idUbicacion = rand(1, 50); // Selecciona un id de ubicación aleatorio
    
    // Generar la consulta SQL
    $sql = "INSERT INTO puntofinal (idpuntofinal, idubicacion, create_at, update_at) 
            VALUES ($i, $idUbicacion, NOW(), NOW());";
    
    echo $sql . "<br>";
}

?>
