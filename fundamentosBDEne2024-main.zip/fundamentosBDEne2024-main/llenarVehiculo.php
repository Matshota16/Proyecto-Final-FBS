<?php

// Generación de registros
for ($i = 1; $i <= 50; $i++) { // Suponiendo que quieres insertar 600 registros
    $nodeplaca = generateRandomString(7); // Generar un número de placa aleatorio de 7 caracteres
    $color = generateRandomColor(); // Generar un color aleatorio
    $marca = generateRandomMarca(); // Generar una marca aleatoria
    $fechaActual = date("Y-m-d H:i:s"); // Fecha y hora actual
    
    // Generar la consulta SQL
    $sql = "INSERT INTO vehiculo (idvehiculo, nodeplaca, color, marca, create_at, update_at) 
            VALUES ($i, '$nodeplaca', '$color', '$marca', '$fechaActual', '$fechaActual');";
    
    echo $sql . "<br>";
}

// Función para generar un string aleatorio
function generateRandomString($length = 7) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// Función para generar un color aleatorio
function generateRandomColor() {
    $colors = array("Rojo", "Azul", "Verde", "Amarillo", "Negro", "Blanco", "Gris");
    return $colors[array_rand($colors)];
}

// Función para generar una marca aleatoria
function generateRandomMarca() {
    $marcas = array("Toyota", "Honda", "Ford", "Chevrolet", "Nissan", "Hyundai", "Volkswagen");
    return $marcas[array_rand($marcas)];
}

?>