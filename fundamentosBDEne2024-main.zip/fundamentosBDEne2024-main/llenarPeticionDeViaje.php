<?php

// Generación de registros
for ($i = 1; $i <= 600; $i++) { // Suponiendo que quieres insertar 300 registros
    $cantidadDePersonas = rand(1, 6); // Número aleatorio de personas entre 1 y 6
    $idCliente = rand(1, 300); // Suponiendo que tienes 300 clientes y los IDs van desde 1 hasta 300
    $idPuntoInicial = rand(1, 300); // Suponiendo que tienes 100 puntos iniciales y los IDs van desde 1 hasta 100
    $idPuntoFinal = rand(1, 300); // Suponiendo que tienes 100 puntos finales y los IDs van desde 1 hasta 100
    $fechaDeInicio = date("Y-m-d H:i:s", strtotime("+" . rand(0, 60) . " days")); // Fecha aleatoria dentro de los próximos 30 días
    
    // Generar la consulta SQL
    $sql = "INSERT INTO peticiondeviaje (idpeticion, cantidaddepersonas, idcliente, idpuntoinicial, idpuntofinal, fechadeinicio, create_at, update_at) 
            VALUES ($i, $cantidadDePersonas, $idCliente, $idPuntoInicial, $idPuntoFinal, '$fechaDeInicio', NOW(), NOW());";
    
    echo $sql . "<br>";
}

?>