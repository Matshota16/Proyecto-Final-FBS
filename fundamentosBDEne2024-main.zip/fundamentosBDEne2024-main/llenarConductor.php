<?php

// Arreglos de datos para generar nombres, apellidos y correos electrónicos aleatorios
$nombres = ["Juan", "María", "Pedro", "Ana", "Luis", "Laura"];
$apellidosPaterno = ["González", "Martínez", "López", "Pérez", "García", "Rodríguez"];
$apellidosMaterno = ["Hernández", "Fernández", "Díaz", "Sánchez", "Romero", "Torres"];
$generos = ["Hombre", "Mujer"];

// Generación de registros
for ($i = 1; $i <= 50; $i++) { // Suponiendo que quieres insertar 300 registros
    $nombre = obtenerAleatorio($nombres);
    $apellidoPaterno = obtenerAleatorio($apellidosPaterno);
    $apellidoMaterno = obtenerAleatorio($apellidosMaterno);
    $genero = obtenerAleatorio($generos);
    $edad = rand(18, 70); // Edad aleatoria entre 18 y 70 años
    $correo = strtolower($nombre) . "." . strtolower($apellidoPaterno) . "@example.com"; // Crear un correo electrónico ficticio
    $telefono = rand(1000000000, 9999999999); // Generar un número de teléfono aleatorio de 10 dígitos
    
    // Generar la consulta SQL
    $sql = "INSERT INTO conductor (idconductor, nombre, apellidopaterno, apellidomaterno, genero, edad, correoelectronico, telefono, create_at, update_at) 
            VALUES ($i, '$nombre', '$apellidoPaterno', '$apellidoMaterno', '$genero', $edad, '$correo', $telefono, NOW(), NOW());";
    
    echo $sql . "<br>";
}

// Función para obtener un elemento aleatorio de un arreglo
function obtenerAleatorio($arreglo) {
    $indice = array_rand($arreglo);
    return $arreglo[$indice];
}

?>